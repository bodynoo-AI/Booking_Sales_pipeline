--
-- PostgreSQL database dump
--

\restrict Ryv2CNgu612XsF7ZqvJyqT12PE0T64RUcKC0MgPyNx67Qn5SZaKdgqNXRO1f6uK

-- Dumped from database version 18.4
-- Dumped by pg_dump version 18.4

-- Started on 2026-07-13 12:45:42

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 872 (class 1247 OID 25812)
-- Name: BookingStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."BookingStatus" AS ENUM (
    'PENDING',
    'ON_HOLD',
    'CONFIRMED',
    'IN_PROGRESS',
    'COMPLETED',
    'CANCELLED'
);


ALTER TYPE public."BookingStatus" OWNER TO postgres;

--
-- TOC entry 881 (class 1247 OID 25842)
-- Name: ChangeOrderStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."ChangeOrderStatus" AS ENUM (
    'PENDING',
    'APPROVED',
    'REJECTED'
);


ALTER TYPE public."ChangeOrderStatus" OWNER TO postgres;

--
-- TOC entry 878 (class 1247 OID 25834)
-- Name: DepositStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."DepositStatus" AS ENUM (
    'PENDING',
    'PAID',
    'OVERDUE'
);


ALTER TYPE public."DepositStatus" OWNER TO postgres;

--
-- TOC entry 875 (class 1247 OID 25826)
-- Name: HoldStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."HoldStatus" AS ENUM (
    'ACTIVE',
    'EXPIRED',
    'RELEASED'
);


ALTER TYPE public."HoldStatus" OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 221 (class 1259 OID 25682)
-- Name: Booking; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Booking" (
    id text NOT NULL,
    "bookingRef" text NOT NULL,
    "clientId" text NOT NULL,
    "eventTitle" text NOT NULL,
    venue text NOT NULL,
    "venueType" text NOT NULL,
    "startDate" timestamp(3) without time zone NOT NULL,
    "endDate" timestamp(3) without time zone NOT NULL,
    "durationLabel" text NOT NULL,
    revenue numeric(12,2) NOT NULL,
    "depositPaid" numeric(12,2) DEFAULT 0 NOT NULL,
    "depositTotal" numeric(12,2) DEFAULT 0 NOT NULL,
    "guestCount" integer,
    notes text,
    "assignedTo" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "cancelledAt" timestamp(3) without time zone,
    "completedAt" timestamp(3) without time zone,
    "confirmedAt" timestamp(3) without time zone,
    "onHoldAt" timestamp(3) without time zone,
    "startedAt" timestamp(3) without time zone,
    status public."BookingStatus" DEFAULT 'PENDING'::public."BookingStatus" NOT NULL,
    "quotationId" text
);


ALTER TABLE public."Booking" OWNER TO postgres;

--
-- TOC entry 226 (class 1259 OID 25918)
-- Name: BookingActivity; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."BookingActivity" (
    id text NOT NULL,
    "bookingId" text NOT NULL,
    action text NOT NULL,
    description text NOT NULL,
    "performedBy" text NOT NULL,
    status text,
    metadata jsonb,
    "timestamp" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."BookingActivity" OWNER TO postgres;

--
-- TOC entry 230 (class 1259 OID 26036)
-- Name: BookingDocument; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."BookingDocument" (
    id text NOT NULL,
    "bookingId" text NOT NULL,
    name text NOT NULL,
    "mimeType" text,
    size integer,
    path text NOT NULL,
    "uploadedBy" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."BookingDocument" OWNER TO postgres;

--
-- TOC entry 225 (class 1259 OID 25902)
-- Name: BookingHandoff; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."BookingHandoff" (
    id text NOT NULL,
    "bookingId" text NOT NULL,
    "handoffTo" text NOT NULL,
    checklist jsonb NOT NULL,
    notes text NOT NULL,
    "handoffAt" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."BookingHandoff" OWNER TO postgres;

--
-- TOC entry 224 (class 1259 OID 25884)
-- Name: ChangeOrder; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ChangeOrder" (
    id text NOT NULL,
    "bookingId" text NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    "amountDelta" numeric(12,2) NOT NULL,
    "requestedBy" text NOT NULL,
    status public."ChangeOrderStatus" DEFAULT 'PENDING'::public."ChangeOrderStatus" NOT NULL,
    "approvedBy" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ChangeOrder" OWNER TO postgres;

--
-- TOC entry 220 (class 1259 OID 25668)
-- Name: Client; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Client" (
    id text NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    phone text,
    "avatarInitials" text NOT NULL,
    "avatarColor" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Client" OWNER TO postgres;

--
-- TOC entry 223 (class 1259 OID 25868)
-- Name: DepositSchedule; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."DepositSchedule" (
    id text NOT NULL,
    "bookingId" text NOT NULL,
    amount numeric(12,2) NOT NULL,
    "dueDate" timestamp(3) without time zone NOT NULL,
    "paidDate" timestamp(3) without time zone,
    status public."DepositStatus" DEFAULT 'PENDING'::public."DepositStatus" NOT NULL,
    method text,
    reference text,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."DepositSchedule" OWNER TO postgres;

--
-- TOC entry 222 (class 1259 OID 25851)
-- Name: Hold; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Hold" (
    id text NOT NULL,
    "bookingId" text NOT NULL,
    reason text NOT NULL,
    "heldBy" text NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    status public."HoldStatus" DEFAULT 'ACTIVE'::public."HoldStatus" NOT NULL,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Hold" OWNER TO postgres;

--
-- TOC entry 228 (class 1259 OID 25980)
-- Name: PasswordReset; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."PasswordReset" (
    id text NOT NULL,
    "userId" text NOT NULL,
    token text NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."PasswordReset" OWNER TO postgres;

--
-- TOC entry 227 (class 1259 OID 25964)
-- Name: User; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."User" (
    id text NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    "passwordHash" text NOT NULL,
    role text DEFAULT 'SalesExecutive'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."User" OWNER TO postgres;

--
-- TOC entry 229 (class 1259 OID 26020)
-- Name: Venue; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Venue" (
    id text NOT NULL,
    name text NOT NULL,
    city text,
    address text,
    capacity integer,
    type text DEFAULT 'General'::text NOT NULL,
    description text,
    status text DEFAULT 'ACTIVE'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Venue" OWNER TO postgres;

--
-- TOC entry 219 (class 1259 OID 25654)
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO postgres;

--
-- TOC entry 5127 (class 0 OID 25682)
-- Dependencies: 221
-- Data for Name: Booking; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public."Booking" VALUES ('1c97f301-e300-4eda-88b3-8fffd3fc954d', 'EH-7059', '7d3afd80-d6c9-4b56-b2d6-4548e038ee35', 'Annual Gala', 'Grand Ballroom', 'Grand Ballroom', '2026-07-01 00:00:00', '2026-07-02 00:00:00', 'FULL DAY', 5000.00, 0.00, 0.00, 250, 'VIP Event', NULL, '2026-06-23 14:08:47.042', '2026-06-23 14:08:47.042', NULL, NULL, NULL, NULL, NULL, 'PENDING', NULL);
INSERT INTO public."Booking" VALUES ('43a256d3-9d1f-4794-92f5-17d364026a2e', 'EH-7344', 'df6497a4-0f39-4600-890f-466ee7aa4573', 'wedding', 'Innovation Lounge', 'Innovation Lounge', '2026-06-08 18:30:00', '2026-06-15 18:30:00', 'FULL DAY', 56000.00, 0.00, 0.00, 120, NULL, NULL, '2026-06-23 15:26:30.576', '2026-06-23 15:26:30.576', NULL, NULL, NULL, NULL, NULL, 'PENDING', NULL);
INSERT INTO public."Booking" VALUES ('9b4e99fb-29f2-4b4a-98dc-c49db491e5b9', 'EH-7286', 'df6497a4-0f39-4600-890f-466ee7aa4573', 'Birthday', 'Board Room', 'Board Room', '2026-06-16 18:30:00', '2026-06-17 18:30:00', 'FULL DAY', 4500.00, 0.00, 0.00, 56, 'Cancelled in app | Cancelled via dashboard', NULL, '2026-06-24 05:51:32.582', '2026-06-24 09:04:22.997', NULL, NULL, NULL, NULL, NULL, 'PENDING', NULL);
INSERT INTO public."Booking" VALUES ('d04fc43f-eb5f-4338-b016-ad9cd25817c3', 'EH-5057', 'df6497a4-0f39-4600-890f-466ee7aa4573', 'concert', 'Grand Ballroom', 'Grand Ballroom', '2026-06-24 18:30:00', '2026-06-25 18:30:00', 'FULL DAY', 23000.00, 0.00, 0.00, 45, NULL, NULL, '2026-06-24 10:37:26.151', '2026-06-24 10:37:26.151', NULL, NULL, NULL, NULL, NULL, 'PENDING', NULL);
INSERT INTO public."Booking" VALUES ('94de7e4e-d433-4f49-8a59-168b0348c049', 'EH-20260624-2359', 'df6497a4-0f39-4600-890f-466ee7aa4573', 'Birthday', 'Innovation Lounge', 'Innovation Lounge', '2026-06-24 18:30:00', '2026-06-25 18:30:00', '1 DAY', 5923.00, 0.00, 0.00, 78, NULL, NULL, '2026-06-24 10:57:36.139', '2026-06-24 10:57:36.139', NULL, NULL, NULL, NULL, NULL, 'PENDING', NULL);
INSERT INTO public."Booking" VALUES ('8aa0dc2b-b96b-4d20-8457-b3a0f062f128', 'EH-8584', 'df6497a4-0f39-4600-890f-466ee7aa4573', 'Birthday', 'Rooftop Terrace', 'Rooftop Terrace', '2026-06-15 18:30:00', '2026-06-16 18:30:00', 'FULL DAY', 2000.00, 0.00, 0.00, 20, 'Hold: Manual hold requested', NULL, '2026-06-23 17:35:45.764', '2026-06-24 09:04:52.12', NULL, NULL, NULL, NULL, NULL, 'PENDING', NULL);
INSERT INTO public."Booking" VALUES ('47644f95-0131-453c-aabf-1bba08a51900', 'EH-8981', 'df6497a4-0f39-4600-890f-466ee7aa4573', 'concert', 'Grand Ballroom', 'Grand Ballroom', '2026-06-24 18:30:00', '2026-06-25 18:30:00', 'FULL DAY', 23000.00, 0.00, 0.00, 45, NULL, NULL, '2026-06-24 10:37:26.451', '2026-06-24 10:38:00.345', NULL, NULL, NULL, NULL, NULL, 'PENDING', NULL);
INSERT INTO public."Booking" VALUES ('fd151eeb-fc7e-487c-b704-f2ef440e702f', 'EH-8342', 'df6497a4-0f39-4600-890f-466ee7aa4573', 'wedding', 'Azure Sky Ballroom', 'Azure Sky Ballroom', '2026-06-14 18:30:00', '2026-06-22 18:30:00', 'FULL DAY', 89556.00, 0.00, 0.00, 78, NULL, NULL, '2026-06-24 10:38:57.982', '2026-06-24 10:38:57.982', NULL, NULL, NULL, NULL, NULL, 'PENDING', NULL);
INSERT INTO public."Booking" VALUES ('ec02c511-a0f1-40b3-aa4c-11f4549dc156', 'EH-4793', 'df6497a4-0f39-4600-890f-466ee7aa4573', 'wedding', 'Rooftop Terrace', 'Rooftop Terrace', '2026-06-30 18:30:00', '2026-07-01 18:30:00', 'FULL DAY', 23000.00, 0.00, 0.00, 56, NULL, NULL, '2026-06-24 10:40:02.651', '2026-06-24 10:40:02.651', NULL, NULL, NULL, NULL, NULL, 'PENDING', NULL);
INSERT INTO public."Booking" VALUES ('379a349b-a088-4c62-af1e-0e2c0eb26b49', 'EH-2750', 'df6497a4-0f39-4600-890f-466ee7aa4573', 'wedding', 'Azure Sky Ballroom', 'Azure Sky Ballroom', '2026-06-29 18:30:00', '2026-06-30 18:30:00', 'FULL DAY', 56456.00, 0.00, 0.00, 29, NULL, NULL, '2026-06-24 09:38:50.686', '2026-06-24 10:28:20.61', NULL, NULL, NULL, NULL, NULL, 'PENDING', NULL);
INSERT INTO public."Booking" VALUES ('aa596a13-2d13-4e7d-99e0-e11abcb9d231', 'EH-3365', 'df6497a4-0f39-4600-890f-466ee7aa4573', 'concert', 'Grand Ballroom', 'Grand Ballroom', '2026-06-24 18:30:00', '2026-06-25 18:30:00', 'FULL DAY', 45000.00, 0.00, 0.00, 23, NULL, NULL, '2026-06-24 10:30:10.869', '2026-06-24 10:30:10.869', NULL, NULL, NULL, NULL, NULL, 'PENDING', NULL);
INSERT INTO public."Booking" VALUES ('589d7341-3e72-4b62-b01d-231eccd5c84f', 'EH-2012', 'df6497a4-0f39-4600-890f-466ee7aa4573', 'concert', 'Grand Ballroom', 'Grand Ballroom', '2026-06-24 18:30:00', '2026-06-25 18:30:00', 'FULL DAY', 45000.00, 0.00, 0.00, 23, NULL, NULL, '2026-06-24 10:30:14.456', '2026-06-24 10:30:14.456', NULL, NULL, NULL, NULL, NULL, 'PENDING', NULL);
INSERT INTO public."Booking" VALUES ('c8837d8b-fdd4-47b2-b283-6a25a344931b', 'EH-9048', 'df6497a4-0f39-4600-890f-466ee7aa4573', 'concert', 'Grand Ballroom', 'Grand Ballroom', '2026-06-24 18:30:00', '2026-06-25 18:30:00', 'FULL DAY', 45000.00, 0.00, 0.00, 23, NULL, NULL, '2026-06-24 10:30:14.697', '2026-06-24 10:30:14.697', NULL, NULL, NULL, NULL, NULL, 'PENDING', NULL);
INSERT INTO public."Booking" VALUES ('1cca0e66-8f16-4536-b975-b6020b3063a5', 'EH-1789', 'df6497a4-0f39-4600-890f-466ee7aa4573', 'concert', 'Grand Ballroom', 'Grand Ballroom', '2026-06-24 18:30:00', '2026-06-25 18:30:00', 'FULL DAY', 45000.00, 0.00, 0.00, 23, NULL, NULL, '2026-06-24 10:30:14.948', '2026-06-24 10:30:14.948', NULL, NULL, NULL, NULL, NULL, 'PENDING', NULL);
INSERT INTO public."Booking" VALUES ('2db8007f-19b4-4f85-8df0-10440a54505d', 'EH-5949', 'df6497a4-0f39-4600-890f-466ee7aa4573', 'concert', 'Grand Ballroom', 'Grand Ballroom', '2026-06-24 18:30:00', '2026-06-25 18:30:00', 'FULL DAY', 45000.00, 0.00, 0.00, 23, NULL, NULL, '2026-06-24 10:30:15.372', '2026-06-24 10:30:15.372', NULL, NULL, NULL, NULL, NULL, 'PENDING', NULL);
INSERT INTO public."Booking" VALUES ('5b809f02-dcc8-48f8-9bef-23d4c407e6ae', 'EH-7088', 'df6497a4-0f39-4600-890f-466ee7aa4573', 'concert', 'Grand Ballroom', 'Grand Ballroom', '2026-06-24 18:30:00', '2026-06-25 18:30:00', 'FULL DAY', 45000.00, 0.00, 0.00, 23, NULL, NULL, '2026-06-24 10:30:15.618', '2026-06-24 10:30:15.618', NULL, NULL, NULL, NULL, NULL, 'PENDING', NULL);
INSERT INTO public."Booking" VALUES ('c34b55aa-a7a2-4720-ae28-45535c49c2b3', 'EH-7301', 'df6497a4-0f39-4600-890f-466ee7aa4573', 'concert', 'Grand Ballroom', 'Grand Ballroom', '2026-06-24 18:30:00', '2026-06-25 18:30:00', 'FULL DAY', 45000.00, 0.00, 0.00, 23, NULL, NULL, '2026-06-24 10:30:15.954', '2026-06-24 10:30:15.954', NULL, NULL, NULL, NULL, NULL, 'PENDING', NULL);
INSERT INTO public."Booking" VALUES ('1b4f9bd8-c5fc-46ad-a34b-25839492b5f9', 'EH-3400', 'df6497a4-0f39-4600-890f-466ee7aa4573', 'concert', 'Grand Ballroom', 'Grand Ballroom', '2026-06-24 18:30:00', '2026-06-25 18:30:00', 'FULL DAY', 45000.00, 0.00, 0.00, 23, NULL, NULL, '2026-06-24 10:30:16.119', '2026-06-24 10:30:16.119', NULL, NULL, NULL, NULL, NULL, 'PENDING', NULL);
INSERT INTO public."Booking" VALUES ('8e774378-2fd5-4c40-9eae-fe56bba86d26', 'EH-5256', 'df6497a4-0f39-4600-890f-466ee7aa4573', 'concert', 'Grand Ballroom', 'Grand Ballroom', '2026-06-24 18:30:00', '2026-06-25 18:30:00', 'FULL DAY', 45000.00, 0.00, 0.00, 23, NULL, NULL, '2026-06-24 10:30:16.284', '2026-06-24 10:30:16.284', NULL, NULL, NULL, NULL, NULL, 'PENDING', NULL);
INSERT INTO public."Booking" VALUES ('3f6e9b2d-74fa-456b-8c43-0619a78e6e76', 'EH-7272', 'df6497a4-0f39-4600-890f-466ee7aa4573', 'concert', 'Grand Ballroom', 'Grand Ballroom', '2026-06-24 18:30:00', '2026-06-25 18:30:00', 'FULL DAY', 45000.00, 0.00, 0.00, 23, NULL, NULL, '2026-06-24 10:36:35.218', '2026-06-24 10:36:35.218', NULL, NULL, NULL, NULL, NULL, 'PENDING', NULL);
INSERT INTO public."Booking" VALUES ('f1235ec5-6f3e-4db7-8fec-204965684d80', 'EH-6516', 'df6497a4-0f39-4600-890f-466ee7aa4573', 'concert', 'Grand Ballroom', 'Grand Ballroom', '2026-06-24 18:30:00', '2026-06-25 18:30:00', 'FULL DAY', 45000.00, 0.00, 0.00, 23, NULL, NULL, '2026-06-24 10:36:43.65', '2026-06-24 10:36:43.65', NULL, NULL, NULL, NULL, NULL, 'PENDING', NULL);
INSERT INTO public."Booking" VALUES ('04691aee-7e71-443b-b23b-833253190a6e', 'EH-3179', 'df6497a4-0f39-4600-890f-466ee7aa4573', 'concert', 'Grand Ballroom', 'Grand Ballroom', '2026-06-24 18:30:00', '2026-06-25 18:30:00', 'FULL DAY', 23000.00, 0.00, 0.00, 45, NULL, NULL, '2026-06-24 10:37:23.042', '2026-06-24 10:37:23.042', NULL, NULL, NULL, NULL, NULL, 'PENDING', NULL);
INSERT INTO public."Booking" VALUES ('8bb5b77e-875b-47b0-8e7b-fa2063b1bdbd', 'EH-1457', 'df6497a4-0f39-4600-890f-466ee7aa4573', 'concert', 'Grand Ballroom', 'Grand Ballroom', '2026-06-24 18:30:00', '2026-06-25 18:30:00', 'FULL DAY', 23000.00, 0.00, 0.00, 45, NULL, NULL, '2026-06-24 10:37:24.179', '2026-06-24 10:37:24.179', NULL, NULL, NULL, NULL, NULL, 'PENDING', NULL);
INSERT INTO public."Booking" VALUES ('3b550bde-5b22-450c-8174-a842d57bc223', 'EH-7743', 'df6497a4-0f39-4600-890f-466ee7aa4573', 'concert', 'Grand Ballroom', 'Grand Ballroom', '2026-06-24 18:30:00', '2026-06-25 18:30:00', 'FULL DAY', 23000.00, 0.00, 0.00, 45, NULL, NULL, '2026-06-24 10:37:24.391', '2026-06-24 10:37:24.391', NULL, NULL, NULL, NULL, NULL, 'PENDING', NULL);
INSERT INTO public."Booking" VALUES ('7f8f52a9-adb7-4b9f-85a8-0622311c94dd', 'EH-9184', 'df6497a4-0f39-4600-890f-466ee7aa4573', 'concert', 'Grand Ballroom', 'Grand Ballroom', '2026-06-24 18:30:00', '2026-06-25 18:30:00', 'FULL DAY', 23000.00, 0.00, 0.00, 45, NULL, NULL, '2026-06-24 10:37:24.557', '2026-06-24 10:37:24.557', NULL, NULL, NULL, NULL, NULL, 'PENDING', NULL);
INSERT INTO public."Booking" VALUES ('ad4022bf-ea6d-4b8a-a908-3e34cd4b322f', 'EH-1125', 'df6497a4-0f39-4600-890f-466ee7aa4573', 'concert', 'Grand Ballroom', 'Grand Ballroom', '2026-06-24 18:30:00', '2026-06-25 18:30:00', 'FULL DAY', 23000.00, 0.00, 0.00, 45, NULL, NULL, '2026-06-24 10:37:24.741', '2026-06-24 10:37:24.741', NULL, NULL, NULL, NULL, NULL, 'PENDING', NULL);
INSERT INTO public."Booking" VALUES ('aff66105-82ec-4bb5-9bc1-a9583e18b6ea', 'EH-9515', 'df6497a4-0f39-4600-890f-466ee7aa4573', 'concert', 'Grand Ballroom', 'Grand Ballroom', '2026-06-24 18:30:00', '2026-06-25 18:30:00', 'FULL DAY', 23000.00, 0.00, 0.00, 45, NULL, NULL, '2026-06-24 10:37:24.888', '2026-06-24 10:37:24.888', NULL, NULL, NULL, NULL, NULL, 'PENDING', NULL);
INSERT INTO public."Booking" VALUES ('72ed447b-4dba-468a-859e-1f06168ff8ad', 'EH-1477', 'df6497a4-0f39-4600-890f-466ee7aa4573', 'concert', 'Grand Ballroom', 'Grand Ballroom', '2026-06-24 18:30:00', '2026-06-25 18:30:00', 'FULL DAY', 23000.00, 0.00, 0.00, 45, NULL, NULL, '2026-06-24 10:37:25.107', '2026-06-24 10:37:25.107', NULL, NULL, NULL, NULL, NULL, 'PENDING', NULL);
INSERT INTO public."Booking" VALUES ('40135e6c-6752-430c-ac6d-360a76bd8dc8', 'EH-4188', 'df6497a4-0f39-4600-890f-466ee7aa4573', 'wedding', 'Rooftop Terrace', 'Rooftop Terrace', '2026-06-30 18:30:00', '2026-07-01 18:30:00', 'FULL DAY', 23000.00, 0.00, 0.00, 56, NULL, NULL, '2026-06-24 10:40:02.759', '2026-06-24 10:40:02.759', NULL, NULL, NULL, NULL, NULL, 'PENDING', NULL);
INSERT INTO public."Booking" VALUES ('c4937e12-5bc5-44e9-a26b-80a039273771', 'EH-2538', 'df6497a4-0f39-4600-890f-466ee7aa4573', 'wedding', 'Rooftop Terrace', 'Rooftop Terrace', '2026-06-30 18:30:00', '2026-07-01 18:30:00', 'FULL DAY', 23000.00, 0.00, 0.00, 56, NULL, NULL, '2026-06-24 10:40:03.009', '2026-06-24 10:40:03.009', NULL, NULL, NULL, NULL, NULL, 'PENDING', NULL);
INSERT INTO public."Booking" VALUES ('f53d87e7-33ad-45be-86f0-c40ce6516e5f', 'EH-20260624-7960', 'df6497a4-0f39-4600-890f-466ee7aa4573', 'Birthday', 'Innovation Lounge', 'Innovation Lounge', '2026-06-24 18:30:00', '2026-06-25 18:30:00', '1 DAY', 5923.00, 0.00, 0.00, 78, NULL, NULL, '2026-06-24 10:57:33.126', '2026-06-24 10:57:33.126', NULL, NULL, NULL, NULL, NULL, 'PENDING', NULL);
INSERT INTO public."Booking" VALUES ('6b8fc7d4-ed6a-402c-afa1-0deddd131539', 'EH-20260624-6488', 'df6497a4-0f39-4600-890f-466ee7aa4573', 'concert', 'Rooftop Terrace', 'Rooftop Terrace', '2026-06-26 18:30:00', '2026-06-27 18:30:00', '1 DAY', 4462.00, 0.00, 0.00, 123, NULL, NULL, '2026-06-24 11:16:41.725', '2026-06-24 11:16:41.725', NULL, NULL, NULL, NULL, NULL, 'PENDING', NULL);
INSERT INTO public."Booking" VALUES ('78140d9e-3c13-4872-a4db-c6ba1cc98851', 'EH-20260624-3738', 'df6497a4-0f39-4600-890f-466ee7aa4573', 'concert', 'Rooftop Terrace', 'Rooftop Terrace', '2026-06-26 18:30:00', '2026-06-27 18:30:00', '1 DAY', 4462.00, 0.00, 0.00, 123, NULL, NULL, '2026-06-24 11:16:43.22', '2026-06-24 11:16:43.22', NULL, NULL, NULL, NULL, NULL, 'PENDING', NULL);
INSERT INTO public."Booking" VALUES ('a2199993-efd6-439a-bc43-c2c09ab7e985', 'EH-20260624-8310', 'df6497a4-0f39-4600-890f-466ee7aa4573', 'wedding', 'Innovation Lounge', 'Innovation Lounge', '2026-06-30 18:30:00', '2026-07-01 18:30:00', '1 DAY', 8951.00, 0.00, 0.00, 75, NULL, NULL, '2026-06-24 11:18:48.77', '2026-06-24 11:18:48.77', NULL, NULL, NULL, NULL, NULL, 'PENDING', NULL);
INSERT INTO public."Booking" VALUES ('f3063454-3c45-4acd-873f-2157be076a72', 'EH-20260625-TWBC2M', 'fb5d2951-aff8-4b3e-a8de-0fdae642fd81', 'wedding', 'Azure Sky Ballroom', 'Azure Sky Ballroom', '2026-06-09 18:30:00', '2026-07-01 18:30:00', '22 DAYS', 89561.00, 0.00, 0.00, 456, 'Hold: Manual hold requested | Cancelled in app | Cancelled via dashboard | Cancelled in app | Cancelled via dashboard', NULL, '2026-06-25 15:01:09.92', '2026-06-25 15:42:29.482', '2026-06-25 15:42:29.479', NULL, '2026-06-25 15:41:47.151', '2026-06-25 15:41:58.969', NULL, 'CANCELLED', NULL);
INSERT INTO public."Booking" VALUES ('6db89c6a-f677-40a4-8db8-3ad4b20bcad9', 'EH-20260625-FBWRU1', 'fb5d2951-aff8-4b3e-a8de-0fdae642fd81', 'wedding', 'Azure Sky Ballroom', 'Azure Sky Ballroom', '2026-06-09 18:30:00', '2026-07-01 18:30:00', '22 DAYS', 89561.00, 0.00, 0.00, 456, 'Hold: Manual hold requested', NULL, '2026-06-25 15:01:08.092', '2026-06-25 15:42:53.226', NULL, NULL, '2026-06-25 15:42:40.082', '2026-06-25 15:42:53.223', NULL, 'ON_HOLD', NULL);
INSERT INTO public."Booking" VALUES ('78dac97f-dcbd-4a54-8886-c7cf3b3f6ac9', 'EH-20260626-LGBILA', 'df6497a4-0f39-4600-890f-466ee7aa4573', 'hghg', 'Azure Sky Ballroom', 'Azure Sky Ballroom', '2026-06-16 18:30:00', '2026-06-29 18:30:00', '13 DAYS', 55.00, 0.00, 0.00, NULL, 'Cancelled in app | Cancelled via dashboard', NULL, '2026-06-26 07:54:58.646', '2026-06-26 07:55:36.588', '2026-06-26 07:55:36.585', NULL, NULL, NULL, NULL, 'CANCELLED', NULL);
INSERT INTO public."Booking" VALUES ('2ddcbcf4-08df-472f-876a-97160e2ce4f3', 'EH-20260626-4S01P2', '4fc7eb93-cd66-4f5b-a5c6-e69809e8d846', 'concert', 'Azure Sky Ballroom', 'Azure Sky Ballroom', '2026-07-01 18:30:00', '2026-07-02 18:30:00', '1 DAY', 89800.00, 0.00, 0.00, 560, 'Hold: Manual hold requested | Hold: Manual hold requested', NULL, '2026-06-26 05:49:06.005', '2026-06-26 11:12:14.105', NULL, NULL, '2026-06-26 05:50:49.604', '2026-06-26 11:12:14.104', '2026-06-26 11:11:38.621', 'ON_HOLD', NULL);
INSERT INTO public."Booking" VALUES ('187d0f5e-8d25-4fa2-9a1e-c518fa2fe95b', 'EH-20260701-7AUDK8', '3a55e372-539e-483e-9781-7a634ca85f38', 'Annual Gala Dinner', 'Rooftop Terrace', 'Rooftop Terrace', '2026-07-14 18:30:00', '2026-07-14 18:30:00', '1 DAY', 562.00, 0.00, 0.00, 5, NULL, NULL, '2026-07-01 09:57:26.462', '2026-07-07 11:34:19.136', NULL, NULL, '2026-07-07 11:34:19.133', NULL, NULL, 'CONFIRMED', NULL);
INSERT INTO public."Booking" VALUES ('663b42fb-46e4-4e3c-906f-3474affc59da', 'EH-20260708-Q8TIED', 'c9e5edec-a888-410f-a0e4-ec4604a653ce', 'Retirement Party ', 'YashoBhoomi Dwarka', 'YashoBhoomi Dwarka', '2026-07-08 18:30:00', '2026-07-09 18:30:00', '1 DAY', 15.00, 0.00, 0.00, 12, '', NULL, '2026-07-08 11:31:33.633', '2026-07-09 10:30:50.127', NULL, NULL, '2026-07-08 11:31:46.059', NULL, '2026-07-08 11:31:52.204', 'IN_PROGRESS', 'QT-456-123');
INSERT INTO public."Booking" VALUES ('0b35c0b8-714f-4929-9920-b578db25483b', 'EH-20260626-YUC5HB', '36377141-74d3-4544-9bbe-2993a3571ebd', 'Birthday', 'Rooftop Terrace', 'Rooftop Terrace', '2026-06-28 18:30:00', '2026-06-29 18:30:00', '1 DAY', 560.00, 0.00, 0.00, 12, NULL, NULL, '2026-06-26 05:46:17.403', '2026-07-08 12:26:51.573', NULL, '2026-07-08 12:26:51.478', '2026-06-26 11:12:24.053', NULL, '2026-06-26 11:12:31.164', 'COMPLETED', NULL);
INSERT INTO public."Booking" VALUES ('de454475-c147-48be-b024-86a2575de325', 'EH-20260626-OWKPPU', '60021fbe-fcda-4f33-8134-53f65ea7a04d', 'Wedding', 'Grand Ballroom', 'Grand Ballroom', '2026-06-28 18:30:00', '2026-06-29 18:30:00', '1 DAY', 8956.00, 0.00, 0.00, 56, NULL, NULL, '2026-06-26 12:02:35.114', '2026-07-08 12:26:51.577', NULL, '2026-07-08 12:26:51.478', '2026-06-27 08:21:17.493', NULL, '2026-07-01 09:44:56.58', 'COMPLETED', NULL);
INSERT INTO public."Booking" VALUES ('0e12726b-f9be-4cd8-9b4c-5bd88886e53a', 'EH-20260626-JIBVF0', '9ca41208-7324-47e1-b267-dfb9ce750ad6', 'concert', 'Grand Ballroom', 'Grand Ballroom', '2026-06-26 18:30:00', '2026-06-27 18:30:00', '1 DAY', 64000.00, 0.00, 0.00, 500, NULL, NULL, '2026-06-26 05:42:14.447', '2026-07-08 12:26:51.582', NULL, '2026-07-08 12:26:51.478', '2026-06-26 11:12:42.867', NULL, '2026-07-08 12:26:51.478', 'COMPLETED', NULL);
INSERT INTO public."Booking" VALUES ('c9585074-bd48-49a3-b075-638195b8307b', 'EH-20260624-5J5ERQ', 'df6497a4-0f39-4600-890f-466ee7aa4573', 'Summit AI', 'Rooftop Terrace', 'Rooftop Terrace', '2026-06-30 18:30:00', '2026-07-01 18:30:00', '1 DAY', 235000.00, 0.00, 0.00, 500, 'Hold: Manual hold requested | Hold: Manual hold requested | Hold: Manual hold requested | Hold: Manual hold requested', NULL, '2026-06-24 11:59:59.059', '2026-07-08 12:26:51.587', NULL, '2026-07-08 12:26:51.478', '2026-06-25 15:43:41.535', NULL, '2026-07-08 12:26:51.478', 'COMPLETED', NULL);
INSERT INTO public."Booking" VALUES ('d81b0318-6ff0-45b7-b540-cbe471ae12b8', 'EH-20260624-6511', 'df6497a4-0f39-4600-890f-466ee7aa4573', 'Birthday', 'Innovation Lounge', 'Innovation Lounge', '2026-06-15 18:30:00', '2026-06-16 18:30:00', '1 DAY', 8956.00, 0.00, 0.00, 456, NULL, NULL, '2026-06-24 11:19:50.371', '2026-07-08 12:26:51.591', NULL, '2026-07-08 12:26:51.478', '2026-06-25 17:28:12.323', NULL, '2026-07-08 12:26:51.478', 'COMPLETED', NULL);
INSERT INTO public."Booking" VALUES ('9a323dba-77cf-4037-aea0-1ff6311207a7', 'EH-20260624-5666', 'df6497a4-0f39-4600-890f-466ee7aa4573', 'wedding', 'Innovation Lounge', 'Innovation Lounge', '2026-06-30 18:30:00', '2026-07-01 18:30:00', '1 DAY', 8951.00, 0.00, 0.00, 75, NULL, NULL, '2026-06-24 11:18:53.537', '2026-07-08 12:26:51.596', NULL, '2026-07-08 12:26:51.478', '2026-07-01 08:35:51.33', NULL, '2026-07-08 12:26:51.478', 'COMPLETED', NULL);


--
-- TOC entry 5132 (class 0 OID 25918)
-- Dependencies: 226
-- Data for Name: BookingActivity; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public."BookingActivity" VALUES ('d3e708b3-92ec-4780-b382-9b3b16377fa9', 'f3063454-3c45-4acd-873f-2157be076a72', 'Booking Confirmed', 'Status changed to CONFIRMED', 'Operations', 'CONFIRMED', NULL, '2026-06-25 15:41:47.185', '2026-06-25 15:41:47.189');
INSERT INTO public."BookingActivity" VALUES ('3bab7e64-4669-47b7-aa54-ea32e51190ba', 'f3063454-3c45-4acd-873f-2157be076a72', 'Booking On Hold', 'Booking moved to hold: Manual hold requested', 'Operations', 'ON_HOLD', '{"holdId": "60413536-0c44-4c00-a1ed-75ec5fa77f97"}', '2026-06-25 15:41:58.974', '2026-06-25 15:41:58.979');
INSERT INTO public."BookingActivity" VALUES ('f2a4e93f-9922-4f31-bd19-ea8a98ade53e', 'f3063454-3c45-4acd-873f-2157be076a72', 'Booking Cancelled', 'Booking cancelled: Cancelled in app', 'Operations', 'CANCELLED', '{"cancellationNotes": "Cancelled via dashboard"}', '2026-06-25 15:42:04.442', '2026-06-25 15:42:04.447');
INSERT INTO public."BookingActivity" VALUES ('50b1c765-2dd8-4715-95d0-43090e9e00d2', 'f3063454-3c45-4acd-873f-2157be076a72', 'Booking Cancelled', 'Booking cancelled: Cancelled in app', 'Operations', 'CANCELLED', '{"cancellationNotes": "Cancelled via dashboard"}', '2026-06-25 15:42:29.513', '2026-06-25 15:42:29.516');
INSERT INTO public."BookingActivity" VALUES ('c5eea2bd-499a-46b2-817a-bb1139bb9b68', '6db89c6a-f677-40a4-8db8-3ad4b20bcad9', 'Booking Confirmed', 'Status changed to CONFIRMED', 'Operations', 'CONFIRMED', NULL, '2026-06-25 15:42:40.116', '2026-06-25 15:42:40.119');
INSERT INTO public."BookingActivity" VALUES ('3fcaec33-682f-4ea7-b771-74ee09927d81', '6db89c6a-f677-40a4-8db8-3ad4b20bcad9', 'Booking On Hold', 'Booking moved to hold: Manual hold requested', 'Operations', 'ON_HOLD', '{"holdId": "388be760-bbee-43f6-85a6-a3310bfa20a2"}', '2026-06-25 15:42:53.23', '2026-06-25 15:42:53.233');
INSERT INTO public."BookingActivity" VALUES ('772296e0-2625-4365-ac28-708f54b64932', 'c9585074-bd48-49a3-b075-638195b8307b', 'Booking On Hold', 'Booking moved to hold: Manual hold requested', 'Operations', 'ON_HOLD', '{"holdId": "cc131f19-fae2-429b-be1a-58df9d3492ed"}', '2026-06-25 15:43:04.089', '2026-06-25 15:43:04.092');
INSERT INTO public."BookingActivity" VALUES ('07f8cd23-ddf6-4bc0-a649-988a1e29b7f2', 'c9585074-bd48-49a3-b075-638195b8307b', 'Booking On Hold', 'Booking moved to hold: Manual hold requested', 'Operations', 'ON_HOLD', '{"holdId": "3dc33702-04bb-4852-846f-6774c949a897"}', '2026-06-25 15:43:05.268', '2026-06-25 15:43:05.271');
INSERT INTO public."BookingActivity" VALUES ('a6b3663e-0e30-4eb2-babf-ca6ec3b095e6', 'c9585074-bd48-49a3-b075-638195b8307b', 'Booking On Hold', 'Booking moved to hold: Manual hold requested', 'Operations', 'ON_HOLD', '{"holdId": "6472a830-8e50-42f6-87c6-8adb3fd3c618"}', '2026-06-25 15:43:05.768', '2026-06-25 15:43:05.771');
INSERT INTO public."BookingActivity" VALUES ('82bd6a8c-f487-404f-8591-ca2f58ff2326', 'c9585074-bd48-49a3-b075-638195b8307b', 'Booking On Hold', 'Booking moved to hold: Manual hold requested', 'Operations', 'ON_HOLD', '{"holdId": "40eb8540-4019-4b64-b70c-f41255c753d4"}', '2026-06-25 15:43:06.052', '2026-06-25 15:43:06.055');
INSERT INTO public."BookingActivity" VALUES ('a2b610a5-1025-4445-bdc0-8887565a85ed', 'c9585074-bd48-49a3-b075-638195b8307b', 'Booking Confirmed', 'Status changed to CONFIRMED', 'Operations', 'CONFIRMED', NULL, '2026-06-25 15:43:41.545', '2026-06-25 15:43:41.548');
INSERT INTO public."BookingActivity" VALUES ('422c5647-90e3-4b8b-a500-b3f2a28c62ec', 'd81b0318-6ff0-45b7-b540-cbe471ae12b8', 'Booking Confirmed', 'Status changed to CONFIRMED', 'Operations', 'CONFIRMED', NULL, '2026-06-25 17:28:12.358', '2026-06-25 17:28:12.364');
INSERT INTO public."BookingActivity" VALUES ('55e9850d-1809-4cd3-b101-96f9bfa5a32a', '0e12726b-f9be-4cd8-9b4c-5bd88886e53a', 'Booking Created', 'Booking EH-20260626-JIBVF0 created', 'System', 'PENDING', '{"venue": "Grand Ballroom", "clientId": "9ca41208-7324-47e1-b267-dfb9ce750ad6"}', '2026-06-26 05:42:14.442', '2026-06-26 05:42:14.46');
INSERT INTO public."BookingActivity" VALUES ('bbc48443-f1d7-4006-bfe0-cf2ace40034a', '0b35c0b8-714f-4929-9920-b578db25483b', 'Booking Created', 'Booking EH-20260626-YUC5HB created', 'System', 'PENDING', '{"venue": "Rooftop Terrace", "clientId": "36377141-74d3-4544-9bbe-2993a3571ebd"}', '2026-06-26 05:46:17.404', '2026-06-26 05:46:17.41');
INSERT INTO public."BookingActivity" VALUES ('37bce186-dab6-4537-85eb-c6c2373cd9ed', '2ddcbcf4-08df-472f-876a-97160e2ce4f3', 'Booking Created', 'Booking EH-20260626-4S01P2 created', 'System', 'PENDING', '{"venue": "Azure Sky Ballroom", "clientId": "4fc7eb93-cd66-4f5b-a5c6-e69809e8d846"}', '2026-06-26 05:49:06.006', '2026-06-26 05:49:06.014');
INSERT INTO public."BookingActivity" VALUES ('6b57aefe-b4e9-40bc-afdd-10f8f17843bb', '2ddcbcf4-08df-472f-876a-97160e2ce4f3', 'Booking Confirmed', 'Status changed to CONFIRMED', 'Operations', 'CONFIRMED', NULL, '2026-06-26 05:50:49.641', '2026-06-26 05:50:49.643');
INSERT INTO public."BookingActivity" VALUES ('ab12b3ea-c37b-4ed0-929c-1b0950bc783c', '78dac97f-dcbd-4a54-8886-c7cf3b3f6ac9', 'Booking Created', 'Booking EH-20260626-LGBILA created', 'System', 'PENDING', '{"venue": "Azure Sky Ballroom", "clientId": "df6497a4-0f39-4600-890f-466ee7aa4573"}', '2026-06-26 07:54:58.65', '2026-06-26 07:54:58.653');
INSERT INTO public."BookingActivity" VALUES ('f1081063-8942-418e-a155-ad62089204df', '78dac97f-dcbd-4a54-8886-c7cf3b3f6ac9', 'Booking Cancelled', 'Booking cancelled: Cancelled in app', 'Operations', 'CANCELLED', '{"cancellationNotes": "Cancelled via dashboard"}', '2026-06-26 07:55:36.598', '2026-06-26 07:55:36.603');
INSERT INTO public."BookingActivity" VALUES ('f66c3add-7b0c-4382-b791-b744f5994f0b', '2ddcbcf4-08df-472f-876a-97160e2ce4f3', 'Event Started', 'Status changed to IN_PROGRESS', 'Operations', 'IN_PROGRESS', NULL, '2026-06-26 11:11:38.658', '2026-06-26 11:11:38.659');
INSERT INTO public."BookingActivity" VALUES ('9fb2cc0d-3a5d-4dbb-a845-b2dfff2783df', '2ddcbcf4-08df-472f-876a-97160e2ce4f3', 'Booking On Hold', 'Booking moved to hold: Manual hold requested', 'Operations', 'ON_HOLD', '{"holdId": "27ab8196-a6c6-47ff-9b23-46909471a1a8"}', '2026-06-26 11:11:48.021', '2026-06-26 11:11:48.022');
INSERT INTO public."BookingActivity" VALUES ('2dab79e2-bb39-4027-9e9b-7d0243139e10', '2ddcbcf4-08df-472f-876a-97160e2ce4f3', 'Booking On Hold', 'Booking moved to hold: Manual hold requested', 'Operations', 'ON_HOLD', '{"holdId": "021092c2-6c77-431c-8e68-5c36993c0a0e"}', '2026-06-26 11:12:14.111', '2026-06-26 11:12:14.112');
INSERT INTO public."BookingActivity" VALUES ('f6314efa-5d6a-422e-afcd-ad063ad58e67', '0b35c0b8-714f-4929-9920-b578db25483b', 'Booking Confirmed', 'Status changed to CONFIRMED', 'Operations', 'CONFIRMED', NULL, '2026-06-26 11:12:24.087', '2026-06-26 11:12:24.088');
INSERT INTO public."BookingActivity" VALUES ('faa5791b-b1bb-4cd6-8bda-359b3493b1b2', '0b35c0b8-714f-4929-9920-b578db25483b', 'Event Started', 'Status changed to IN_PROGRESS', 'Operations', 'IN_PROGRESS', NULL, '2026-06-26 11:12:31.17', '2026-06-26 11:12:31.171');
INSERT INTO public."BookingActivity" VALUES ('36c03388-b1f0-44ee-972f-932b365b0c5a', '0e12726b-f9be-4cd8-9b4c-5bd88886e53a', 'Booking Confirmed', 'Status changed to CONFIRMED', 'Operations', 'CONFIRMED', NULL, '2026-06-26 11:12:42.901', '2026-06-26 11:12:42.903');
INSERT INTO public."BookingActivity" VALUES ('09921d61-173b-46ca-9bb9-abfa4b7bcc8c', 'de454475-c147-48be-b024-86a2575de325', 'Booking Created', 'Booking EH-20260626-OWKPPU created', 'System', 'PENDING', '{"venue": "Grand Ballroom", "clientId": "60021fbe-fcda-4f33-8134-53f65ea7a04d"}', '2026-06-26 12:02:35.122', '2026-06-26 12:02:35.123');
INSERT INTO public."BookingActivity" VALUES ('a0cfb80a-d433-471b-9ab2-4dd339c0ef53', 'de454475-c147-48be-b024-86a2575de325', 'Booking Confirmed', 'Status changed to CONFIRMED', 'Operations', 'CONFIRMED', NULL, '2026-06-27 08:21:17.501', '2026-06-27 08:21:17.517');
INSERT INTO public."BookingActivity" VALUES ('01684a48-b3ec-4d3e-88f8-977bc3138aa8', 'de454475-c147-48be-b024-86a2575de325', 'Deposit Scheduled', 'Deposit of $45230.00 scheduled', 'Operations', 'PENDING', '{"depositId": "31e91582-396a-435c-b1a9-3d6e1b3f5539"}', '2026-06-27 09:03:23.752', '2026-06-27 09:03:23.757');
INSERT INTO public."BookingActivity" VALUES ('9048ae2e-8fa0-453a-83d6-4d239928d177', '9a323dba-77cf-4037-aea0-1ff6311207a7', 'Booking Confirmed', 'Status changed to CONFIRMED', 'Operations', 'CONFIRMED', '{}', '2026-07-01 08:35:51.396', '2026-07-01 08:35:51.398');
INSERT INTO public."BookingActivity" VALUES ('3f52a015-004a-4f61-b6e0-8905f668cc74', 'de454475-c147-48be-b024-86a2575de325', 'Event Started', 'Status changed to IN_PROGRESS', 'Operations', 'IN_PROGRESS', NULL, '2026-07-01 09:44:56.596', '2026-07-01 09:44:56.597');
INSERT INTO public."BookingActivity" VALUES ('7e979c5e-e0c6-4839-a027-b8a4414c8fe4', '187d0f5e-8d25-4fa2-9a1e-c518fa2fe95b', 'Booking Created', 'Booking EH-20260701-7AUDK8 created', 'System', 'PENDING', '{"venue": "Rooftop Terrace", "clientId": "3a55e372-539e-483e-9781-7a634ca85f38"}', '2026-07-01 09:57:26.456', '2026-07-01 09:57:26.473');
INSERT INTO public."BookingActivity" VALUES ('86e6446e-a89d-4f94-9f5d-7feced8316ed', '187d0f5e-8d25-4fa2-9a1e-c518fa2fe95b', 'Booking Confirmed', 'Status changed to CONFIRMED', 'Operations', 'CONFIRMED', NULL, '2026-07-07 11:34:19.144', '2026-07-07 11:34:19.146');
INSERT INTO public."BookingActivity" VALUES ('0c9f5c7c-290d-490e-ab21-da73e5770717', '663b42fb-46e4-4e3c-906f-3474affc59da', 'Booking Created', 'Booking EH-20260708-Q8TIED created', 'System', 'PENDING', '{"venue": "YashoBhoomi Dwarka", "clientId": "c9e5edec-a888-410f-a0e4-ec4604a653ce"}', '2026-07-08 11:31:33.657', '2026-07-08 11:31:33.658');
INSERT INTO public."BookingActivity" VALUES ('0f6d95c1-723d-4347-b0de-47e3b35c4b5f', '663b42fb-46e4-4e3c-906f-3474affc59da', 'Booking Confirmed', 'Status changed to CONFIRMED', 'Operations', 'CONFIRMED', NULL, '2026-07-08 11:31:46.097', '2026-07-08 11:31:46.099');
INSERT INTO public."BookingActivity" VALUES ('e876ef86-f1f5-4269-a830-5a2bd7bf688f', '663b42fb-46e4-4e3c-906f-3474affc59da', 'Event Started', 'Status changed to IN_PROGRESS', 'Operations', 'IN_PROGRESS', NULL, '2026-07-08 11:31:52.236', '2026-07-08 11:31:52.238');
INSERT INTO public."BookingActivity" VALUES ('d53c8398-faec-4e20-a70b-a7917ac75698', '0e12726b-f9be-4cd8-9b4c-5bd88886e53a', 'status_change', 'Automatically moved to In Progress (event start time reached)', 'System (Automatic)', 'IN_PROGRESS', NULL, '2026-07-08 12:26:51.55', '2026-07-08 12:26:51.55');
INSERT INTO public."BookingActivity" VALUES ('54ddd067-38c4-4bf3-96c6-f248109085a6', 'c9585074-bd48-49a3-b075-638195b8307b', 'status_change', 'Automatically moved to In Progress (event start time reached)', 'System (Automatic)', 'IN_PROGRESS', NULL, '2026-07-08 12:26:51.559', '2026-07-08 12:26:51.559');
INSERT INTO public."BookingActivity" VALUES ('e2c574fd-bee1-4eb4-b8c2-802d39cb368b', 'd81b0318-6ff0-45b7-b540-cbe471ae12b8', 'status_change', 'Automatically moved to In Progress (event start time reached)', 'System (Automatic)', 'IN_PROGRESS', NULL, '2026-07-08 12:26:51.564', '2026-07-08 12:26:51.564');
INSERT INTO public."BookingActivity" VALUES ('de983e5a-58c6-43ee-9a8b-885d44c6d46f', '9a323dba-77cf-4037-aea0-1ff6311207a7', 'status_change', 'Automatically moved to In Progress (event start time reached)', 'System (Automatic)', 'IN_PROGRESS', NULL, '2026-07-08 12:26:51.568', '2026-07-08 12:26:51.568');
INSERT INTO public."BookingActivity" VALUES ('888f3f23-ea8c-417a-9c10-7565e231b073', '9a323dba-77cf-4037-aea0-1ff6311207a7', 'status_change', 'Automatically moved to In Progress (event start time reached)', 'System (Automatic)', 'IN_PROGRESS', NULL, '2026-07-08 12:26:51.569', '2026-07-08 12:26:51.569');
INSERT INTO public."BookingActivity" VALUES ('641eadc9-bb72-4e63-aceb-1aa7264a41bc', '0b35c0b8-714f-4929-9920-b578db25483b', 'status_change', 'Automatically moved to Completed (event end time reached)', 'System (Automatic)', 'COMPLETED', NULL, '2026-07-08 12:26:51.575', '2026-07-08 12:26:51.575');
INSERT INTO public."BookingActivity" VALUES ('da842c9b-aa20-4cf9-bbc7-99813a668371', 'de454475-c147-48be-b024-86a2575de325', 'status_change', 'Automatically moved to Completed (event end time reached)', 'System (Automatic)', 'COMPLETED', NULL, '2026-07-08 12:26:51.58', '2026-07-08 12:26:51.58');
INSERT INTO public."BookingActivity" VALUES ('acfdc8e1-2748-4003-b7d5-0ada2a471afc', '0e12726b-f9be-4cd8-9b4c-5bd88886e53a', 'status_change', 'Automatically moved to Completed (event end time reached)', 'System (Automatic)', 'COMPLETED', NULL, '2026-07-08 12:26:51.585', '2026-07-08 12:26:51.585');
INSERT INTO public."BookingActivity" VALUES ('fcc4db27-223e-47f3-9d59-51d245957a71', 'c9585074-bd48-49a3-b075-638195b8307b', 'status_change', 'Automatically moved to Completed (event end time reached)', 'System (Automatic)', 'COMPLETED', NULL, '2026-07-08 12:26:51.59', '2026-07-08 12:26:51.59');
INSERT INTO public."BookingActivity" VALUES ('e799fc62-f083-4a28-8a57-136f0075dd49', 'd81b0318-6ff0-45b7-b540-cbe471ae12b8', 'status_change', 'Automatically moved to Completed (event end time reached)', 'System (Automatic)', 'COMPLETED', NULL, '2026-07-08 12:26:51.594', '2026-07-08 12:26:51.594');
INSERT INTO public."BookingActivity" VALUES ('b8bd3378-d15a-4f1b-bb45-f7a94561ed03', '9a323dba-77cf-4037-aea0-1ff6311207a7', 'status_change', 'Automatically moved to Completed (event end time reached)', 'System (Automatic)', 'COMPLETED', NULL, '2026-07-08 12:26:51.598', '2026-07-08 12:26:51.598');
INSERT INTO public."BookingActivity" VALUES ('4cfbc55f-d8b0-4117-a448-bd3f22dfa5f3', '0e12726b-f9be-4cd8-9b4c-5bd88886e53a', 'status_change', 'Automatically moved to In Progress (event start time reached)', 'System (Automatic)', 'IN_PROGRESS', NULL, '2026-07-08 12:26:51.552', '2026-07-08 12:26:51.552');
INSERT INTO public."BookingActivity" VALUES ('404b2143-f73e-478d-b370-883f486b907c', 'c9585074-bd48-49a3-b075-638195b8307b', 'status_change', 'Automatically moved to In Progress (event start time reached)', 'System (Automatic)', 'IN_PROGRESS', NULL, '2026-07-08 12:26:51.56', '2026-07-08 12:26:51.56');
INSERT INTO public."BookingActivity" VALUES ('e65b8f8c-5f19-45c0-9b80-09be0aef9cf7', 'd81b0318-6ff0-45b7-b540-cbe471ae12b8', 'status_change', 'Automatically moved to In Progress (event start time reached)', 'System (Automatic)', 'IN_PROGRESS', NULL, '2026-07-08 12:26:51.565', '2026-07-08 12:26:51.565');
INSERT INTO public."BookingActivity" VALUES ('9832b4af-a5d2-41f7-87f6-6a2a8481a006', '0b35c0b8-714f-4929-9920-b578db25483b', 'status_change', 'Automatically moved to Completed (event end time reached)', 'System (Automatic)', 'COMPLETED', NULL, '2026-07-08 12:26:51.576', '2026-07-08 12:26:51.576');
INSERT INTO public."BookingActivity" VALUES ('4f74f456-0804-4b05-b48a-5b0c99ab1d3a', 'de454475-c147-48be-b024-86a2575de325', 'status_change', 'Automatically moved to Completed (event end time reached)', 'System (Automatic)', 'COMPLETED', NULL, '2026-07-08 12:26:51.58', '2026-07-08 12:26:51.58');
INSERT INTO public."BookingActivity" VALUES ('8a57ef4e-b02a-486b-baef-f9ca2372fd8e', '0e12726b-f9be-4cd8-9b4c-5bd88886e53a', 'status_change', 'Automatically moved to Completed (event end time reached)', 'System (Automatic)', 'COMPLETED', NULL, '2026-07-08 12:26:51.585', '2026-07-08 12:26:51.585');
INSERT INTO public."BookingActivity" VALUES ('2e4117e8-528b-4261-9ae0-f18a57505a5d', 'c9585074-bd48-49a3-b075-638195b8307b', 'status_change', 'Automatically moved to Completed (event end time reached)', 'System (Automatic)', 'COMPLETED', NULL, '2026-07-08 12:26:51.589', '2026-07-08 12:26:51.589');
INSERT INTO public."BookingActivity" VALUES ('69a0f6e4-dd43-4616-bedd-01627ba88e56', 'd81b0318-6ff0-45b7-b540-cbe471ae12b8', 'status_change', 'Automatically moved to Completed (event end time reached)', 'System (Automatic)', 'COMPLETED', NULL, '2026-07-08 12:26:51.594', '2026-07-08 12:26:51.594');
INSERT INTO public."BookingActivity" VALUES ('4053c71e-0c61-4887-9a3b-ad7e2ed39264', '9a323dba-77cf-4037-aea0-1ff6311207a7', 'status_change', 'Automatically moved to Completed (event end time reached)', 'System (Automatic)', 'COMPLETED', NULL, '2026-07-08 12:26:51.599', '2026-07-08 12:26:51.599');
INSERT INTO public."BookingActivity" VALUES ('be5a950c-77dd-4d46-a587-e047bd681401', '663b42fb-46e4-4e3c-906f-3474affc59da', 'Booking Updated', 'Booking EH-20260708-Q8TIED was updated', 'Operations', 'IN_PROGRESS', '{"updatedFields": ["eventTitle", "quotationId", "venue", "venueType", "startDate", "endDate", "durationLabel", "revenue", "guestCount", "notes"]}', '2026-07-09 10:30:50.135', '2026-07-09 10:30:50.136');
INSERT INTO public."BookingActivity" VALUES ('698db559-9c1f-466a-ab4b-9085931ab147', 'de454475-c147-48be-b024-86a2575de325', 'Deposit Updated', 'Deposit of $45230.00 updated to status PAID', 'Operations', 'PAID', '{"depositId": "31e91582-396a-435c-b1a9-3d6e1b3f5539"}', '2026-07-09 10:31:28.209', '2026-07-09 10:31:28.212');


--
-- TOC entry 5136 (class 0 OID 26036)
-- Dependencies: 230
-- Data for Name: BookingDocument; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 5131 (class 0 OID 25902)
-- Dependencies: 225
-- Data for Name: BookingHandoff; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 5130 (class 0 OID 25884)
-- Dependencies: 224
-- Data for Name: ChangeOrder; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 5126 (class 0 OID 25668)
-- Dependencies: 220
-- Data for Name: Client; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public."Client" VALUES ('7d3afd80-d6c9-4b56-b2d6-4548e038ee35', 'John Smith', 'john@example.com', '9999999999', 'JS', NULL, '2026-06-23 14:08:47.024', '2026-06-23 14:08:47.024');
INSERT INTO public."Client" VALUES ('fb5d2951-aff8-4b3e-a8de-0fdae642fd81', 'bob', 'jagmeetsingh3909@gmail.com', '456123789', 'B', NULL, '2026-06-25 15:01:08.073', '2026-06-25 15:01:09.912');
INSERT INTO public."Client" VALUES ('9ca41208-7324-47e1-b267-dfb9ce750ad6', 'Alisahal', 'alisaha23@gmail.com', '456789159', 'A', NULL, '2026-06-26 05:42:14.43', '2026-06-26 05:42:14.43');
INSERT INTO public."Client" VALUES ('36377141-74d3-4544-9bbe-2993a3571ebd', 'Adarsh', 'adarsh45@gmail.com', '753159842', 'A', NULL, '2026-06-26 05:46:17.323', '2026-06-26 05:46:17.323');
INSERT INTO public."Client" VALUES ('4fc7eb93-cd66-4f5b-a5c6-e69809e8d846', 'Jagmeet', 'jagmeet56@gmail.com', '895623474', 'J', NULL, '2026-06-26 05:49:05.965', '2026-06-26 05:49:05.965');
INSERT INTO public."Client" VALUES ('df6497a4-0f39-4600-890f-466ee7aa4573', 'nbnbbn', 'bodynoo950@gmail.com', '2356894563', 'N', NULL, '2026-06-23 15:26:30.554', '2026-06-26 07:54:58.633');
INSERT INTO public."Client" VALUES ('60021fbe-fcda-4f33-8134-53f65ea7a04d', 'Rahul', 'rahul23@gmail.com', '987654231', 'R', NULL, '2026-06-26 12:02:35.072', '2026-06-26 12:02:35.072');
INSERT INTO public."Client" VALUES ('edba706d-cb04-4f35-a01d-b3f598418e23', 'Unknown Client', 'no-email+1782549053973@local.invalid', '', '', NULL, '2026-06-27 08:30:54.093', '2026-06-27 08:30:54.093');
INSERT INTO public."Client" VALUES ('333a6874-51ee-4829-8fb5-4c60b3376023', 'Unknown Client', 'no-email+1782549055305@local.invalid', '', '', NULL, '2026-06-27 08:30:55.308', '2026-06-27 08:30:55.308');
INSERT INTO public."Client" VALUES ('73826c5b-2a3f-43e2-9995-d4c2ddf1afb0', 'Unknown Client', 'no-email+1782549084547@local.invalid', '', '', NULL, '2026-06-27 08:31:24.551', '2026-06-27 08:31:24.551');
INSERT INTO public."Client" VALUES ('d352c4b7-df13-4a89-b42c-0b4a7e4fd6b3', 'Unknown Client', 'no-email+1782549087958@local.invalid', '', '', NULL, '2026-06-27 08:31:27.961', '2026-06-27 08:31:27.961');
INSERT INTO public."Client" VALUES ('3a55e372-539e-483e-9781-7a634ca85f38', 'Vijay', 'vijay23@gmail.com', '159789456', 'V', NULL, '2026-07-01 09:57:26.444', '2026-07-01 09:57:26.444');
INSERT INTO public."Client" VALUES ('c9e5edec-a888-410f-a0e4-ec4604a653ce', 'Neha', 'neha55@gmail.com', '9865312555', 'N', NULL, '2026-07-08 11:31:33.609', '2026-07-09 10:30:50.087');


--
-- TOC entry 5129 (class 0 OID 25868)
-- Dependencies: 223
-- Data for Name: DepositSchedule; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public."DepositSchedule" VALUES ('31e91582-396a-435c-b1a9-3d6e1b3f5539', 'de454475-c147-48be-b024-86a2575de325', 45230.00, '2026-06-01 18:30:00', '2026-05-31 18:30:00', 'PAID', 'card', '1234', NULL, '2026-06-27 09:03:23.744', '2026-07-09 10:31:28.209');


--
-- TOC entry 5128 (class 0 OID 25851)
-- Dependencies: 222
-- Data for Name: Hold; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public."Hold" VALUES ('60413536-0c44-4c00-a1ed-75ec5fa77f97', 'f3063454-3c45-4acd-873f-2157be076a72', 'Manual hold requested', 'Operations', '2026-06-28 15:41:58.921', 'ACTIVE', NULL, '2026-06-25 15:41:58.968', '2026-06-25 15:41:58.968');
INSERT INTO public."Hold" VALUES ('388be760-bbee-43f6-85a6-a3310bfa20a2', '6db89c6a-f677-40a4-8db8-3ad4b20bcad9', 'Manual hold requested', 'Operations', '2026-06-28 15:42:53.151', 'ACTIVE', NULL, '2026-06-25 15:42:53.196', '2026-06-25 15:42:53.196');
INSERT INTO public."Hold" VALUES ('cc131f19-fae2-429b-be1a-58df9d3492ed', 'c9585074-bd48-49a3-b075-638195b8307b', 'Manual hold requested', 'Operations', '2026-06-28 15:43:03.996', 'ACTIVE', NULL, '2026-06-25 15:43:04.055', '2026-06-25 15:43:04.055');
INSERT INTO public."Hold" VALUES ('3dc33702-04bb-4852-846f-6774c949a897', 'c9585074-bd48-49a3-b075-638195b8307b', 'Manual hold requested', 'Operations', '2026-06-28 15:43:05.19', 'ACTIVE', NULL, '2026-06-25 15:43:05.234', '2026-06-25 15:43:05.234');
INSERT INTO public."Hold" VALUES ('6472a830-8e50-42f6-87c6-8adb3fd3c618', 'c9585074-bd48-49a3-b075-638195b8307b', 'Manual hold requested', 'Operations', '2026-06-28 15:43:05.68', 'ACTIVE', NULL, '2026-06-25 15:43:05.732', '2026-06-25 15:43:05.732');
INSERT INTO public."Hold" VALUES ('40eb8540-4019-4b64-b70c-f41255c753d4', 'c9585074-bd48-49a3-b075-638195b8307b', 'Manual hold requested', 'Operations', '2026-06-28 15:43:05.992', 'ACTIVE', NULL, '2026-06-25 15:43:06.03', '2026-06-25 15:43:06.03');
INSERT INTO public."Hold" VALUES ('27ab8196-a6c6-47ff-9b23-46909471a1a8', '2ddcbcf4-08df-472f-876a-97160e2ce4f3', 'Manual hold requested', 'Operations', '2026-06-29 11:11:47.955', 'ACTIVE', NULL, '2026-06-26 11:11:47.988', '2026-06-26 11:11:47.988');
INSERT INTO public."Hold" VALUES ('021092c2-6c77-431c-8e68-5c36993c0a0e', '2ddcbcf4-08df-472f-876a-97160e2ce4f3', 'Manual hold requested', 'Operations', '2026-06-29 11:12:14.037', 'ACTIVE', NULL, '2026-06-26 11:12:14.076', '2026-06-26 11:12:14.076');


--
-- TOC entry 5134 (class 0 OID 25980)
-- Dependencies: 228
-- Data for Name: PasswordReset; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 5133 (class 0 OID 25964)
-- Dependencies: 227
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public."User" VALUES ('328f3ae3-60ce-4388-99a3-67f2b6c6a4a8', 'Admin', 'admin00@gmail.com', '$2b$12$CKZkfwcWxEjUoYHFOzLWLudU5EMDMOoQO.t7gnwqWpm9p2aFAa7jy', 'SalesExecutive', '2026-07-01 10:35:42.291', '2026-07-01 10:35:42.291');


--
-- TOC entry 5135 (class 0 OID 26020)
-- Dependencies: 229
-- Data for Name: Venue; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public."Venue" VALUES ('86d6c61b-0f9a-45b3-a65d-749a497003d9', 'YashoBhoomi Dwarka', 'New Delhi', 'Sector 25 Dwarka Dwarka New Delhi Delhi 110061 India New Delhi, India', 2300, 'General', 'Yashobhoomi, located in Sector 25, Dwarka, Delhi, is the largest convention center in India and Asia by area. It covers a total of 890,000 square meters and includes 15 convention centers, with a capacity to accommodate 11,000 delegates. The center features a 6,000-seater auditorium, multiple meeting rooms, and a multipurpose arena with a seating capacity of 20,000. Yashobhoomi was inaugurated on September 17, 2023, and is designed to host a variety of events, including international conferences and trade shows, making it a significant player in India''s event management landscape', 'ACTIVE', '2026-07-08 11:29:03.024', '2026-07-08 11:29:03.024');


--
-- TOC entry 5125 (class 0 OID 25654)
-- Dependencies: 219
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public._prisma_migrations VALUES ('1bcff717-1c1c-434a-92d9-c5e1df7a7abc', '2eae5bade7c06d47d86e17c0e76fed38d00fed6853f27016bbb1ce6e00967698', '2026-06-23 19:22:44.734683+05:30', '20260623135244_init', NULL, NULL, '2026-06-23 19:22:44.714694+05:30', 1);
INSERT INTO public._prisma_migrations VALUES ('ec0942a0-081f-4faa-9a85-28bfbd0f82a5', '0cb7e5571f9a39e82803d622d39179ad8c3bccb22a7f0c10a347716365065a4d', '2026-06-25 21:08:13.544133+05:30', '20260625153813_dashboard', NULL, NULL, '2026-06-25 21:08:13.473859+05:30', 1);


--
-- TOC entry 4956 (class 2606 OID 25933)
-- Name: BookingActivity BookingActivity_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."BookingActivity"
    ADD CONSTRAINT "BookingActivity_pkey" PRIMARY KEY (id);


--
-- TOC entry 4969 (class 2606 OID 26050)
-- Name: BookingDocument BookingDocument_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."BookingDocument"
    ADD CONSTRAINT "BookingDocument_pkey" PRIMARY KEY (id);


--
-- TOC entry 4954 (class 2606 OID 25917)
-- Name: BookingHandoff BookingHandoff_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."BookingHandoff"
    ADD CONSTRAINT "BookingHandoff_pkey" PRIMARY KEY (id);


--
-- TOC entry 4941 (class 2606 OID 25707)
-- Name: Booking Booking_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Booking"
    ADD CONSTRAINT "Booking_pkey" PRIMARY KEY (id);


--
-- TOC entry 4951 (class 2606 OID 25901)
-- Name: ChangeOrder ChangeOrder_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ChangeOrder"
    ADD CONSTRAINT "ChangeOrder_pkey" PRIMARY KEY (id);


--
-- TOC entry 4938 (class 2606 OID 25681)
-- Name: Client Client_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Client"
    ADD CONSTRAINT "Client_pkey" PRIMARY KEY (id);


--
-- TOC entry 4949 (class 2606 OID 25883)
-- Name: DepositSchedule DepositSchedule_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."DepositSchedule"
    ADD CONSTRAINT "DepositSchedule_pkey" PRIMARY KEY (id);


--
-- TOC entry 4946 (class 2606 OID 25867)
-- Name: Hold Hold_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Hold"
    ADD CONSTRAINT "Hold_pkey" PRIMARY KEY (id);


--
-- TOC entry 4961 (class 2606 OID 25993)
-- Name: PasswordReset PasswordReset_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PasswordReset"
    ADD CONSTRAINT "PasswordReset_pkey" PRIMARY KEY (id);


--
-- TOC entry 4959 (class 2606 OID 25979)
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- TOC entry 4966 (class 2606 OID 26035)
-- Name: Venue Venue_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Venue"
    ADD CONSTRAINT "Venue_pkey" PRIMARY KEY (id);


--
-- TOC entry 4935 (class 2606 OID 25667)
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- TOC entry 4967 (class 1259 OID 26052)
-- Name: BookingDocument_bookingId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "BookingDocument_bookingId_idx" ON public."BookingDocument" USING btree ("bookingId");


--
-- TOC entry 4952 (class 1259 OID 25936)
-- Name: BookingHandoff_bookingId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "BookingHandoff_bookingId_key" ON public."BookingHandoff" USING btree ("bookingId");


--
-- TOC entry 4939 (class 1259 OID 25709)
-- Name: Booking_bookingRef_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Booking_bookingRef_key" ON public."Booking" USING btree ("bookingRef");


--
-- TOC entry 4942 (class 1259 OID 25937)
-- Name: Booking_startDate_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Booking_startDate_idx" ON public."Booking" USING btree ("startDate");


--
-- TOC entry 4943 (class 1259 OID 25938)
-- Name: Booking_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Booking_status_idx" ON public."Booking" USING btree (status);


--
-- TOC entry 4936 (class 1259 OID 25708)
-- Name: Client_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Client_email_key" ON public."Client" USING btree (email);


--
-- TOC entry 4947 (class 1259 OID 25935)
-- Name: DepositSchedule_dueDate_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "DepositSchedule_dueDate_status_idx" ON public."DepositSchedule" USING btree ("dueDate", status);


--
-- TOC entry 4944 (class 1259 OID 25934)
-- Name: Hold_expiresAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Hold_expiresAt_idx" ON public."Hold" USING btree ("expiresAt");


--
-- TOC entry 4962 (class 1259 OID 25996)
-- Name: PasswordReset_token_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "PasswordReset_token_key" ON public."PasswordReset" USING btree (token);


--
-- TOC entry 4963 (class 1259 OID 25995)
-- Name: PasswordReset_userId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "PasswordReset_userId_key" ON public."PasswordReset" USING btree ("userId");


--
-- TOC entry 4957 (class 1259 OID 25994)
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- TOC entry 4964 (class 1259 OID 26051)
-- Name: Venue_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Venue_name_key" ON public."Venue" USING btree (name);


--
-- TOC entry 4975 (class 2606 OID 25959)
-- Name: BookingActivity BookingActivity_bookingId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."BookingActivity"
    ADD CONSTRAINT "BookingActivity_bookingId_fkey" FOREIGN KEY ("bookingId") REFERENCES public."Booking"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 4977 (class 2606 OID 26053)
-- Name: BookingDocument BookingDocument_bookingId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."BookingDocument"
    ADD CONSTRAINT "BookingDocument_bookingId_fkey" FOREIGN KEY ("bookingId") REFERENCES public."Booking"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 4974 (class 2606 OID 25954)
-- Name: BookingHandoff BookingHandoff_bookingId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."BookingHandoff"
    ADD CONSTRAINT "BookingHandoff_bookingId_fkey" FOREIGN KEY ("bookingId") REFERENCES public."Booking"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 4970 (class 2606 OID 25710)
-- Name: Booking Booking_clientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Booking"
    ADD CONSTRAINT "Booking_clientId_fkey" FOREIGN KEY ("clientId") REFERENCES public."Client"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 4973 (class 2606 OID 25949)
-- Name: ChangeOrder ChangeOrder_bookingId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ChangeOrder"
    ADD CONSTRAINT "ChangeOrder_bookingId_fkey" FOREIGN KEY ("bookingId") REFERENCES public."Booking"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 4972 (class 2606 OID 25944)
-- Name: DepositSchedule DepositSchedule_bookingId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."DepositSchedule"
    ADD CONSTRAINT "DepositSchedule_bookingId_fkey" FOREIGN KEY ("bookingId") REFERENCES public."Booking"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 4971 (class 2606 OID 25939)
-- Name: Hold Hold_bookingId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Hold"
    ADD CONSTRAINT "Hold_bookingId_fkey" FOREIGN KEY ("bookingId") REFERENCES public."Booking"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 4976 (class 2606 OID 25997)
-- Name: PasswordReset PasswordReset_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PasswordReset"
    ADD CONSTRAINT "PasswordReset_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


-- Completed on 2026-07-13 12:45:42

--
-- PostgreSQL database dump complete
--

\unrestrict Ryv2CNgu612XsF7ZqvJyqT12PE0T64RUcKC0MgPyNx67Qn5SZaKdgqNXRO1f6uK

